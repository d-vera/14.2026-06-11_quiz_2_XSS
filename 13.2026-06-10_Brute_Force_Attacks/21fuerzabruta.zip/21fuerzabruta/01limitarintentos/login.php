<?php
session_start();
if (!isset($_SESSION['intentos'])) {
    $_SESSION['intentos'] = 0;
}

if ($_SESSION['intentos'] >= 2) {
    die("Demasiados intentos. Intenta más tarde.");
    //La sesión queda bloqueada indefinidamente hasta que el navegador se cierre o la sesión expire por configuración del servidor. (Aprox. 24 min)
}

$usuariook = 'admin';
$passwordok = '123456';

if ($_POST['usuario'] === $usuariook && $_POST['password'] === $passwordok) {
    echo "¡Bienvenido!";
    $_SESSION['intentos'] = 0;
} else {
    $_SESSION['intentos']++;
    echo "Credenciales incorrectas. Intento No.:" . $_SESSION['intentos'];
}
?>