<?php
//colocamos el script en uso horario
date_default_timezone_set('America/La_Paz');

// IP del cliente
$ip = $_SERVER['REMOTE_ADDR'];
//archivo de ips bloqueadas
$archivo = 'bloqueos.txt';
$intentosmaximos = 5;
$tiempobloqueo = 1 * 60; // 1 minuto (60 segs)

// Leer archivo de bloqueos
if (file_exists($archivo)) {
    $bloqueos = json_decode(file_get_contents($archivo), true);
} else {
    $bloqueos = [];
}

// Verificar si la IP está bloqueada
if (isset($bloqueos[$ip]))
{
    $info = $bloqueos[$ip];
    if ($info['bloqueadohasta'] > time())
    {
        die("Tu IP está bloqueada. Intenta después de " . date("H:i:s", $info['bloqueadohasta']));
    }
    elseif ($info['intentos'] >= $intentosmaximos)
    {
        // Limpiar si el tiempo ya pasó
        unset($bloqueos[$ip]);
        file_put_contents($archivo, json_encode($bloqueos));
    }
}

// Credenciales válidas
$usuariook = 'admin';
$passwordok = '123456';

if ($_POST['usuario'] === $usuariook && $_POST['password'] === $passwordok)
{
    echo "¡Login exitoso!";
    
    // Limpiar registro si existe
    if (isset($bloqueos[$ip]))
    {
        unset($bloqueos[$ip]);
        file_put_contents($archivo, json_encode($bloqueos));
    }

}
else
{
    // Fallo de acceso: incrementar contador
    if (!isset($bloqueos[$ip]))
    {
        $bloqueos[$ip] = [
            'intentos' => 1,
            'bloqueadohasta' => 0
        ];
    }
    else
    {
        $bloqueos[$ip]['intentos']++;
        if ($bloqueos[$ip]['intentos'] >= $intentosmaximos)
        {
            $bloqueos[$ip]['bloqueadohasta'] = time() + $tiempobloqueo;
            echo "Demasiados intentos fallidos. IP bloqueada por 1 minuto.";
        }
    }

    file_put_contents($archivo, json_encode($bloqueos));
    
    //Verifica si NO está definida la clave 'bloqueadohasta' para la IP
    //La hora del bloqueo es menor que la hora actual (bloqueo ya expiro)
    if (!isset($bloqueos[$ip]['bloqueadohasta']) || $bloqueos[$ip]['bloqueadohasta'] < time())
    {
        echo " Credenciales incorrectas. Intento #" . $bloqueos[$ip]['intentos'];
    }
}
?>
