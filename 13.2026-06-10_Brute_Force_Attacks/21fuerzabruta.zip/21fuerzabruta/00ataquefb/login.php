<?php
$usuariook = 'admin';
$passwordok = '123456';

if ($_POST['usuario'] === $usuariook && $_POST['password'] === $passwordok) {
    echo "¡Bienvenido!";
} else {
    echo "Credenciales incorrectas.";
}
?>